import { Context, Session, h, Schema } from 'koishi'
import axios from 'axios'
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist'
import { createCanvas } from 'canvas'
import { randomUUID } from 'crypto'
import { mkdirSync, writeFileSync, unlinkSync } from 'fs'
import { join, resolve } from 'path'
import { pathToFileURL } from 'url'
import XLSX from 'xlsx'

// 配置 PDF.js worker 路径
GlobalWorkerOptions.workerSrc = require.resolve('pdfjs-dist/legacy/build/pdf.worker.js')

// 扩展 Koishi Context 类型
declare module 'koishi' {
  interface Context {
    redis?: {
      get(key: string): Promise<string | null>
      setex(key: string, seconds: number, value: string): Promise<void>
    }
  }
}

interface ChartData {
  pdfPath: string
  name_cn: string
}

// ChartFox 相关接口
interface ChartFoxAirport {
  id: number
  ident: string
  icao_code: string
  iata_code: string | null
  name: string
  type: string
  latitude: number
  longitude: number
  elevation_ft: number
  iso_a2_country: string
  has_charts: boolean
  has_sources: boolean
}

interface ChartFoxChart {
  id: string
  parent_id: string | null
  airport_icao: string
  name: string
  code: string | null
  type: number
  type_key: string
  meta: Array<{
    type: number
    type_key: string
    value: string[]
  }>
  view_url: string
  has_georeferences: boolean
}

interface ChartFoxApiResponse<T> {
  current_page: number
  data: T[]
  total: number
}

interface OAuthTokenResponse {
  access_token: string
  token_type: string
  expires_in: number
  scope: string
}

export const name = 'eaip-chart'

// 定义配置 Schema
export interface Config {
  chartFoxClientId?: string
  chartFoxClientSecret?: string
  chartFoxToken?: string
}

export const Config: Schema<Config> = Schema.object({
  chartFoxClientId: Schema.string()
    .description('ChartFox OAuth Client ID')
    .role('secret'),
  chartFoxClientSecret: Schema.string()
    .description('ChartFox OAuth Client Secret')
    .role('secret'),
  chartFoxToken: Schema.string()
    .description('ChartFox 访问令牌 (如果已直接获取)')
    .role('secret'),
})

// 工具函数：清洗文件名，去除非法字符
function sanitizeFilename(filename: string): string {
  return filename.replace(/[^a-zA-Z0-9-_\.]/g, '_')
}

// 辅助函数：生成带有当前世界时间的日志信息
function logInfo(message: string): void {
  console.log(`[${new Date().toISOString()}] ${message}`)
}
function logError(message: string, error?: any): void {
  console.error(`[${new Date().toISOString()}] ${message}`, error || '')
}

// -------------------------
// ChartFox API 服务类
// -------------------------
class ChartFoxService {
  private clientId: string
  private clientSecret: string
  private accessToken: string | null = null
  private tokenExpiry: Date | null = null
  private baseURL = 'https://api.chartfox.org'
  private oauthURL = 'https://api.chartfox.org/oauth'

  constructor(clientId: string, clientSecret: string) {
    this.clientId = clientId
    this.clientSecret = clientSecret
  }

  // 设置直接使用的访问令牌
  setAccessToken(token: string) {
    this.accessToken = token
    this.tokenExpiry = new Date(Date.now() + 3600 * 1000) // 假设1小时后过期
  }

  // 获取认证头
  private getAuthHeaders() {
    if (!this.accessToken) {
      throw new Error('未获取到有效的访问令牌')
    }
    return {
      'Authorization': `Bearer ${this.accessToken}`,
      'Content-Type': 'application/json'
    }
  }

  // 获取 OAuth 访问令牌
  async authenticate(): Promise<void> {
    try {
      logInfo('[ChartFox] 正在获取 OAuth 访问令牌...')
      
      const authHeader = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64')
      
      const response = await axios.post<OAuthTokenResponse>(
        `${this.oauthURL}/token`,
        'grant_type=client_credentials',
        {
          headers: {
            'Authorization': `Basic ${authHeader}`,
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          timeout: 10000
        }
      )

      this.accessToken = response.data.access_token
      this.tokenExpiry = new Date(Date.now() + (response.data.expires_in * 1000))
      
      logInfo('[ChartFox] OAuth 认证成功，令牌已获取')
    } catch (error) {
      logError('[ChartFox] OAuth 认证失败:', error)
      throw new Error(`ChartFox 认证失败: ${error.response?.data?.error_description || error.message}`)
    }
  }

  // 检查令牌是否有效
  private async ensureTokenValid(): Promise<void> {
    if (!this.accessToken || (this.tokenExpiry && new Date() >= this.tokenExpiry)) {
      await this.authenticate()
    }
  }

  // 下载文件
  async downloadFile(url: string): Promise<Buffer> {
    await this.ensureTokenValid()
    
    try {
      logInfo(`[ChartFox] 下载文件: ${url}`)
      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        headers: this.getAuthHeaders(),
        timeout: 20000
      })
      logInfo(`[ChartFox] 文件下载成功，大小: ${response.data.byteLength} 字节`)
      return response.data
    } catch (error) {
      logError('[ChartFox] 文件下载失败:', error)
      throw error
    }
  }

  // 搜索机场
  async searchAirports(query: string): Promise<ChartFoxAirport[]> {
    await this.ensureTokenValid()
    
    try {
      logInfo(`[ChartFox] 搜索机场: ${query}`)
      const response = await axios.get<ChartFoxApiResponse<ChartFoxAirport>>(
        `${this.baseURL}/v2/airports`,
        {
          headers: this.getAuthHeaders(),
          params: {
            query: query,
            identQuery: query,
            supported: true
          },
          timeout: 10000
        }
      )
      logInfo(`[ChartFox] 找到 ${response.data.data.length} 个机场`)
      return response.data.data
    } catch (error) {
      logError('[ChartFox] 搜索机场失败:', error)
      throw error
    }
  }

  // 获取机场详情
  async getAirport(icao: string): Promise<ChartFoxAirport> {
    await this.ensureTokenValid()
    
    try {
      logInfo(`[ChartFox] 获取机场详情: ${icao}`)
      const response = await axios.get<ChartFoxAirport>(
        `${this.baseURL}/v2/airports/${icao}`,
        {
          headers: this.getAuthHeaders(),
          timeout: 10000
        }
      )
      return response.data
    } catch (error) {
      logError(`[ChartFox] 获取机场 ${icao} 详情失败:`, error)
      throw error
    }
  }

  // 获取机场航图列表
  async getAirportCharts(icao: string): Promise<ChartFoxChart[]> {
    await this.ensureTokenValid()
    
    try {
      logInfo(`[ChartFox] 获取机场航图: ${icao}`)
      const response = await axios.get<ChartFoxApiResponse<ChartFoxChart>>(
        `${this.baseURL}/v2/airports/${icao}/charts`,
        {
          headers: this.getAuthHeaders(),
          timeout: 10000
        }
      )
      logInfo(`[ChartFox] 找到 ${response.data.data.length} 个航图`)
      return response.data.data
    } catch (error) {
      logError(`[ChartFox] 获取机场 ${icao} 航图失败:`, error)
      throw error
    }
  }

  // 获取详细航图信息
  async getChartDetail(chartId: string): Promise<any> {
    await this.ensureTokenValid()
    
    try {
      logInfo(`[ChartFox] 获取航图详情: ${chartId}`)
      const response = await axios.get(
        `${this.baseURL}/v2/charts/${chartId}`,
        {
          headers: this.getAuthHeaders(),
          timeout: 10000
        }
      )
      return response.data
    } catch (error) {
      logError(`[ChartFox] 获取航图详情失败:`, error)
      throw error
    }
  }
}

// -------------------------
// 分列选项图片生成函数
// -------------------------
const generateOptionsImages = async (charts: ChartData[]): Promise<Buffer[]> => {
  const perColumn = 18
  const maxRowsPerImage = 30
  const total = charts.length
  const columnCount = Math.ceil(total / perColumn)

  const fontSize = 24
  const lineHeight = fontSize * 1.5
  const padding = 20
  const columnGap = 30
  const tempCanvas = createCanvas(1, 1)
  const ctx = tempCanvas.getContext('2d')
  ctx.font = `${fontSize}px "Microsoft YaHei"`

  const textMetrics = charts.map((c, i) => {
    const text = `${i + 1}. ${c.name_cn}`
    return {
      text,
      width: ctx.measureText(text).width
    }
  })

  const columnWidths: number[] = []
  for (let col = 0; col < columnCount; col++) {
    let maxWidth = 0
    const start = col * perColumn
    const end = Math.min(start + perColumn, total)
    for (let i = start; i < end; i++) {
      const spaceWidth = ctx.measureText('  ').width
      maxWidth = Math.max(maxWidth, textMetrics[i].width + spaceWidth)
    }
    columnWidths.push(maxWidth)
  }

  const columnRows = perColumn + 2
  const canvasHeight = padding * 2 + columnRows * lineHeight
  const canvasWidth = padding * 2 + columnWidths.reduce((a, b) => a + b, 0) + columnGap * (columnCount - 1)

  const images: Buffer[] = []

  for (let startIndex = 0; startIndex < charts.length; startIndex += perColumn * columnCount) {
    const chunk = charts.slice(startIndex, startIndex + perColumn * columnCount)
    const canvas = createCanvas(canvasWidth, canvasHeight)
    const drawCtx = canvas.getContext('2d')
    drawCtx.fillStyle = '#ffffff'
    drawCtx.fillRect(0, 0, canvas.width, canvas.height)
    drawCtx.fillStyle = '#333333'
    drawCtx.font = `${fontSize}px "Microsoft YaHei"`

    let xOffset = padding

    for (let col = 0; col < columnCount; col++) {
      const columnWidth = columnWidths[col]
      const colStart = col * perColumn
      const colEnd = Math.min(colStart + perColumn, chunk.length)
      let yOffset = padding + lineHeight

      for (let i = colStart; i < colEnd; i++) {
        drawCtx.fillText(textMetrics[startIndex + i].text, xOffset, yOffset)
        yOffset += lineHeight
      }

      yOffset += lineHeight
      xOffset += columnWidth + columnGap
    }

    images.push(canvas.toBuffer('image/png'))
  }

  return images
}

// ChartFox 航图选项生成函数
const generateChartFoxOptionsImages = async (charts: ChartFoxChart[]): Promise<Buffer[]> => {
  const perColumn = 18
  const maxRowsPerImage = 30
  const total = charts.length
  const columnCount = Math.ceil(total / perColumn)

  const fontSize = 20
  const lineHeight = fontSize * 1.5
  const padding = 20
  const columnGap = 30
  const tempCanvas = createCanvas(1, 1)
  const ctx = tempCanvas.getContext('2d')
  ctx.font = `${fontSize}px "Microsoft YaHei"`

  const textMetrics = charts.map((c, i) => {
    const text = `${i + 1}. ${c.type_key} - ${c.name}`
    return {
      text,
      width: ctx.measureText(text).width
    }
  })

  const columnWidths: number[] = []
  for (let col = 0; col < columnCount; col++) {
    let maxWidth = 0
    const start = col * perColumn
    const end = Math.min(start + perColumn, total)
    for (let i = start; i < end; i++) {
      const spaceWidth = ctx.measureText('  ').width
      maxWidth = Math.max(maxWidth, textMetrics[i].width + spaceWidth)
    }
    columnWidths.push(maxWidth)
  }

  const columnRows = perColumn + 2
  const canvasHeight = padding * 2 + columnRows * lineHeight
  const canvasWidth = padding * 2 + columnWidths.reduce((a, b) => a + b, 0) + columnGap * (columnCount - 1)

  const images: Buffer[] = []

  for (let startIndex = 0; startIndex < charts.length; startIndex += perColumn * columnCount) {
    const chunk = charts.slice(startIndex, startIndex + perColumn * columnCount)
    const canvas = createCanvas(canvasWidth, canvasHeight)
    const drawCtx = canvas.getContext('2d')
    drawCtx.fillStyle = '#ffffff'
    drawCtx.fillRect(0, 0, canvas.width, canvas.height)
    drawCtx.fillStyle = '#333333'
    drawCtx.font = `${fontSize}px "Microsoft YaHei"`

    let xOffset = padding

    for (let col = 0; col < columnCount; col++) {
      const columnWidth = columnWidths[col]
      const colStart = col * perColumn
      const colEnd = Math.min(colStart + perColumn, chunk.length)
      let yOffset = padding + lineHeight

      for (let i = colStart; i < colEnd; i++) {
        drawCtx.fillText(textMetrics[startIndex + i].text, xOffset, yOffset)
        yOffset += lineHeight
      }

      yOffset += lineHeight
      xOffset += columnWidth + columnGap
    }

    images.push(canvas.toBuffer('image/png'))
  }

  return images
}

// -------------------------
// PDF 相关辅助函数
// -------------------------
const getPdfDocument = async (pdfBuffer: Buffer) => {
  logInfo('[getPdfDocument] 正在加载 PDF 文档...')
  const loadingTask = getDocument({
    data: new Uint8Array(pdfBuffer),
    useSystemFonts: true,
    verbosity: 0,
  })
  const pdfDoc = await loadingTask.promise
  logInfo(`[getPdfDocument] PDF 文档加载成功，共 ${pdfDoc.numPages} 页`)
  return pdfDoc
}

const renderPdfPage = async (pdf: any, pageNumber: number): Promise<Buffer> => {
  logInfo(`[renderPdfPage] 正在渲染第 ${pageNumber} 页...`)
  const page = await pdf.getPage(pageNumber)
  const viewport = page.getViewport({ scale: 1.5 })
  const canvas = createCanvas(viewport.width, viewport.height)
  const ctx = canvas.getContext('2d')

  await page.render({
    canvasContext: ctx as any,
    viewport,
    background: 'rgba(255,255,255,1)',
  }).promise

  logInfo(`[renderPdfPage] 第 ${pageNumber} 页渲染完成`)
  return canvas.toBuffer('image/jpeg', { quality: 0.8 })
}

// -------------------------
// 主逻辑
// -------------------------
export function apply(ctx: Context, config: Config) {
  logInfo('[apply] 初始化 eaip-chart 模块...')
  
  // 初始化 ChartFox 服务
  let chartFoxService: ChartFoxService | null = null
  
  if (config.chartFoxToken) {
    // 如果配置了直接使用的令牌
    logInfo('[apply] 使用直接配置的 ChartFox Token')
    // 这里我们仍然需要 Client ID 和 Secret 来创建服务实例
    // 如果没有提供，我们可以创建一个虚拟的服务实例
    if (config.chartFoxClientId && config.chartFoxClientSecret) {
      chartFoxService = new ChartFoxService(config.chartFoxClientId, config.chartFoxClientSecret)
      chartFoxService.setAccessToken(config.chartFoxToken)
    }
  } else if (config.chartFoxClientId && config.chartFoxClientSecret) {
    // 如果配置了 OAuth Client ID 和 Secret
    logInfo('[apply] 使用 OAuth 方式初始化 ChartFox 服务')
    chartFoxService = new ChartFoxService(config.chartFoxClientId, config.chartFoxClientSecret)
    
    // 测试认证
    chartFoxService.authenticate().catch(error => {
      logError('[apply] ChartFox 认证失败:', error)
      chartFoxService = null
    })
  } else {
    logInfo('[apply] ChartFox 凭据未配置，将仅使用本地数据源')
  }

  // 从 Excel 文件中读取机场数据
  const AIRPORT_DATA = (() => {
    logInfo('[AIRPORT_DATA] 正在读取 Excel 机场数据...')
    try {
      const workbook = XLSX.readFile(resolve(__dirname, 'airports.xlsx'))
      const sheet = workbook.Sheets[workbook.SheetNames[0]]
      const jsonData = XLSX.utils.sheet_to_json<{ CODE_ID: string; TXT_NAME: string; CODE_IATA: string }>(sheet, { 
        header: ['CODE_ID', 'TXT_NAME', 'CODE_IATA'],
        range: 1
      })
      const data = jsonData
        .filter(a => a.CODE_ID && a.CODE_IATA)
        .map(a => ({
          icao: a.CODE_ID.toUpperCase(),
          name: a.TXT_NAME,
          iata: a.CODE_IATA.toUpperCase()
        }))
      logInfo(`[AIRPORT_DATA] 成功加载 ${data.length} 个机场数据`)
      return data
    } catch (error) {
      logError('[AIRPORT_DATA] 读取机场数据失败:', error)
      return []
    }
  })()

  // 创建临时文件目录
  const TEMP_DIR = resolve(__dirname, 'temp')
  mkdirSync(TEMP_DIR, { recursive: true })
  logInfo('[apply] 临时目录路径：' + TEMP_DIR)

  // 处理 EAIP 数据源查询
  const handleEAIPQuery = async (session: Session, icao: string, options: any) => {
    try {
      logInfo('[EAIP] 正在从远程接口获取航图数据...')
      const { data } = await axios.get<ChartData[]>(
        'http://49.234.192.240/Data/JsonPath/AD.JSON',
        { timeout: 15000 }
      )
      logInfo(`[EAIP] 接收到航图数据，共 ${data.length} 条记录`)

      const charts = data.filter(item =>
        item.pdfPath.toUpperCase().includes(`/TERMINAL/${icao}/`) &&
        item.name_cn.toUpperCase().startsWith(icao)
      )
      logInfo(`[EAIP] 筛选结果：与机场 ${icao} 匹配的航图数量为 ${charts.length}`)

      if (!charts.length) {
        // 如果在 EAIP 中找不到，尝试使用 ChartFox
        if (chartFoxService) {
          await session.send(`在 EAIP 中未找到 ${icao} 的航图，正在尝试从 ChartFox 查询...`)
          return await handleChartFoxQuery(session, icao, options)
        } else {
          return `未找到 ${icao} 的航图信息（EAIP 数据源）`
        }
      }

      const optionImages = await generateOptionsImages(charts)
      const choiceMessage = [
        `找到以下航图（共 ${charts.length} 个）：`,
        ...optionImages.map(image => h.image(image, 'image/png')),
        '请回复编号选择：'
      ]
      logInfo('[EAIP] 正在向用户发送选项图片')
      await session.send(choiceMessage)

      const choice = await session.prompt(60000)
      if (!choice) {
        logInfo('[EAIP] 用户选择超时')
        return '选择超时，请重新查询'
      }
      const index = parseInt(choice) - 1
      if (isNaN(index) || index < 0 || index >= charts.length) {
        logError('[EAIP] 用户输入的选择无效: ' + choice)
        return '无效的选择'
      }

      const selected = charts[index]
      logInfo(`[EAIP] 用户选择的航图: ${selected.name_cn}`)
      const pdfUrl = `http://49.234.192.240/${selected.pdfPath}`
      logInfo('[EAIP] 开始下载 PDF 文件，下载地址: ' + pdfUrl)

      const { data: pdfBuffer } = await axios.get(pdfUrl, {
        responseType: 'arraybuffer',
        timeout: 20000,
      })
      logInfo('[EAIP] PDF 文件下载成功，文件大小: ' + pdfBuffer.byteLength)

      const fileName = `${sanitizeFilename(selected.name_cn)}.pdf`
      const filePath = join(TEMP_DIR, fileName)
      writeFileSync(filePath, pdfBuffer)
      logInfo('[EAIP] PDF 文件已保存到: ' + filePath)

      const pdf = await getPdfDocument(pdfBuffer)
      const totalPages = pdf.numPages
      logInfo(`[EAIP] PDF 文件总页数: ${totalPages}`)

      if (options.page < 1 || options.page > totalPages) {
        pdf.destroy()
        const errorMsg = `页码无效，有效范围 1-${totalPages}`
        logError('[EAIP] ' + errorMsg)
        throw new Error(errorMsg)
      }

      const messageParts: any[] = [
        `📄 ${selected.name_cn}\n`,
        `📖 页码：${options.page}/${totalPages}\n`,
        `航图数据源于 WWW.eaipchina.cn 的公开数据`,
      ]

      if (totalPages >= 2) {
        logInfo('[EAIP] 检测到多页 PDF，发送文件链接给用户')
        messageParts.push(h.file(pathToFileURL(filePath).href))
      } else {
        logInfo('[EAIP] 检测到单页 PDF，开始生成预览图')
        try {
          const previewImage = await renderPdfPage(pdf, options.page)
          messageParts.push(h.image(previewImage, 'image/jpeg'))
        } catch (renderError) {
          logError('[EAIP] 预览图生成失败:', renderError)
        }
      }

      logInfo('[EAIP] 正在发送最终结果给用户')
      await session.send(messageParts)
      pdf.destroy()

      setTimeout(() => {
        try {
          logInfo(`[EAIP] 5 分钟后清理临时 PDF 文件: ${filePath}`)
          unlinkSync(filePath)
        } catch (cleanupError) {
          logError('[EAIP] 临时文件清理失败:', cleanupError)
        }
      }, 300_000)

    } catch (error: any) {
      logError('[EAIP] 航图查询出现错误:', error)
      throw error
    }
  }

  // 处理 ChartFox 数据源查询
  const handleChartFoxQuery = async (session: Session, icao: string, options: any) => {
    if (!chartFoxService) {
      throw new Error('ChartFox 服务未配置或认证失败')
    }

    try {
      logInfo(`[ChartFox] 开始查询机场 ${icao}`)
      
      // 首先验证机场是否存在
      const airport = await chartFoxService.getAirport(icao)
      logInfo(`[ChartFox] 找到机场: ${airport.name}`)

      if (!airport.has_charts) {
        return `机场 ${icao} 在 ChartFox 中没有可用的航图`
      }

      // 获取航图列表
      const charts = await chartFoxService.getAirportCharts(icao)
      if (!charts.length) {
        return `机场 ${icao} 在 ChartFox 中没有找到航图`
      }

      // 显示航图选择界面
      const optionImages = await generateChartFoxOptionsImages(charts)
      const choiceMessage = [
        `📊 ChartFox 找到以下航图（共 ${charts.length} 个）：`,
        `📍 机场: ${airport.name} (${icao})`,
        ...optionImages.map(image => h.image(image, 'image/png')),
        '请回复编号选择：'
      ]
      await session.send(choiceMessage)

      const choice = await session.prompt(60000)
      if (!choice) {
        return '选择超时，请重新查询'
      }
      const index = parseInt(choice) - 1
      if (isNaN(index) || index < 0 || index >= charts.length) {
        return '无效的选择'
      }

      const selectedChart = charts[index]
      logInfo(`[ChartFox] 用户选择的航图: ${selectedChart.name}`)

      // 获取航图详情
      const chartDetail = await chartFoxService.getChartDetail(selectedChart.id)
      
      const messageParts: any[] = [
        `📄 ${selectedChart.name}\n`,
        `🏷️ 类型: ${selectedChart.type_key}\n`,
        `📍 机场: ${airport.name} (${icao})\n`,
        `🔗 查看链接: ${selectedChart.view_url}\n`,
        `📊 数据来源: ChartFox API`
      ]

      // 如果有源URL，显示源信息
      if (chartDetail.source_url) {
        messageParts.push(`🌐 源链接: ${chartDetail.source_url}`)
      }

      if (chartDetail.source) {
        messageParts.push(`📋 提供商: ${chartDetail.source.display_name}`)
      }

      await session.send(messageParts)

      // 如果有文件链接，尝试下载和显示
      if (chartDetail.files && chartDetail.files.length > 0) {
        const file = chartDetail.files[0]
        try {
          logInfo(`[ChartFox] 开始下载航图文件: ${file.url}`)
          const fileBuffer = await chartFoxService.downloadFile(file.url)

          if (file.type === 0 || file.type === 1) { // PDF 或图片
            const fileName = `${sanitizeFilename(selectedChart.name)}.${file.type === 0 ? 'pdf' : 'jpg'}`
            const filePath = join(TEMP_DIR, fileName)
            writeFileSync(filePath, fileBuffer)

            if (file.type === 0) { // PDF
              const pdf = await getPdfDocument(fileBuffer)
              const totalPages = pdf.numPages
              
              if (options.page < 1 || options.page > totalPages) {
                pdf.destroy()
                await session.send(`页码无效，有效范围 1-${totalPages}`)
              } else if (totalPages >= 2) {
                await session.send(h.file(pathToFileURL(filePath).href))
              } else {
                try {
                  const previewImage = await renderPdfPage(pdf, options.page)
                  await session.send(h.image(previewImage, 'image/jpeg'))
                } catch (renderError) {
                  logError('[ChartFox] 预览图生成失败:', renderError)
                  await session.send(h.file(pathToFileURL(filePath).href))
                }
              }
              pdf.destroy()
            } else { // 图片
              await session.send(h.image(fileBuffer, 'image/jpeg'))
            }

            // 清理临时文件
            setTimeout(() => {
              try {
                unlinkSync(filePath)
              } catch (cleanupError) {
                logError('[ChartFox] 临时文件清理失败:', cleanupError)
              }
            }, 300_000)
          }
        } catch (fileError) {
          logError('[ChartFox] 文件下载失败:', fileError)
          await session.send('⚠️ 文件下载失败，请使用查看链接访问航图')
        }
      }

    } catch (error: any) {
      logError('[ChartFox] 查询失败:', error)
      if (error.response?.status === 404) {
        return `机场 ${icao} 在 ChartFox 中未找到`
      } else if (error.response?.status === 401) {
        return 'ChartFox 认证失败，请检查凭据配置'
      } else {
        throw new Error(`ChartFox 查询失败: ${error.message}`)
      }
    }
  }

  // 注册命令
  ctx.command('naip <code:string>', '查询机场航图（支持ICAO/IATA/中文名称）')
    .alias('航图', 'eaip')
    .option('page', '-p <页码:number>', { fallback: 1 })
    .action(async ({ session, options }, codeInput) => {
      logInfo('[command naip] 接收到输入: ' + codeInput)
      if (!session) return

      const code = (codeInput || '').trim()
      let icao: string

      // 机场代码识别逻辑
      if (/^[A-Z]{3}$/.test(code.toUpperCase())) {
        logInfo(`[command naip] 将 ${code} 识别为 IATA 代码`)
        const airports = AIRPORT_DATA.filter(a => a.iata === code.toUpperCase())
        if (airports.length === 0) {
          // 如果在本地找不到，直接使用 ChartFox
          if (chartFoxService) {
            await session.send(`在本地数据库中未找到 IATA 代码 ${code}，正在尝试从 ChartFox 查询...`)
            return await handleChartFoxQuery(session, code.toUpperCase(), options)
          } else {
            return `未找到 IATA 代码 ${code} 对应的机场`
          }
        }
        if (airports.length > 1) {
          const msg = [
            `找到多个匹配机场：`,
            ...airports.map((a, i) => `${i + 1}. ${a.name} (${a.icao})`)
          ].join('\n')
          await session.send(msg + '\n请回复编号选择：')
          const choice = await session.prompt(60000)
          const index = parseInt(choice) - 1
          if (!airports[index]) return '选择无效'
          icao = airports[index].icao
        } else {
          icao = airports[0].icao
        }
      } else if (/^[A-Z]{4}$/.test(code.toUpperCase())) {
        logInfo(`[command naip] 将 ${code} 识别为 ICAO 代码`)
        icao = code.toUpperCase()
        
        // 检查是否在本地数据库中
        const localAirport = AIRPORT_DATA.find(a => a.icao === icao)
        if (!localAirport && chartFoxService) {
          await session.send(`在本地数据库中未找到 ICAO 代码 ${icao}，正在尝试从 ChartFox 查询...`)
          return await handleChartFoxQuery(session, icao, options)
        }
      } else {
        logInfo(`[command naip] 将 ${code} 识别为中文名称搜索`)
        const keyword = code.toLowerCase()
        const airports = AIRPORT_DATA.filter(a => a.name.toLowerCase().includes(keyword))
        if (airports.length === 0) {
          if (chartFoxService) {
            await session.send(`在本地数据库中未找到包含 "${code}" 的机场，正在尝试从 ChartFox 搜索...`)
            const chartFoxAirports = await chartFoxService.searchAirports(code)
            if (chartFoxAirports.length === 0) {
              return `未找到包含 "${code}" 的机场`
            }
            if (chartFoxAirports.length > 1) {
              const msg = [
                `ChartFox 找到多个匹配机场：`,
                ...chartFoxAirports.map((a, i) => `${i + 1}. ${a.name} (${a.icao_code})`)
              ].join('\n')
              await session.send(msg + '\n请回复编号选择：')
              const choice = await session.prompt(60000)
              const index = parseInt(choice) - 1
              if (!chartFoxAirports[index]) return '选择无效'
              icao = chartFoxAirports[index].icao_code
            } else {
              icao = chartFoxAirports[0].icao_code
            }
            return await handleChartFoxQuery(session, icao, options)
          } else {
            return `未找到包含 "${code}" 的机场`
          }
        }
        if (airports.length > 1) {
          const msg = [
            `找到多个包含 "${code}" 的机场：`,
            ...airports.map((a, i) => `${i + 1}. ${a.name} (${a.icao}/${a.iata})`)
          ].join('\n')
          await session.send(msg + '\n请回复编号选择：')
          const choice = await session.prompt(60000)
          const index = parseInt(choice) - 1
          if (!airports[index]) return '选择无效'
          icao = airports[index].icao
        } else {
          icao = airports[0].icao
        }
      }

      logInfo(`[command naip] 最终选定机场 ICAO 代码: ${icao}`)

      try {
        return await handleEAIPQuery(session, icao, options)
      } catch (error: any) {
        logError('[command naip] 航图查询出现错误:', error)
        return `操作失败：${error.message}`
      }
    })

  // 添加 ChartFox 状态检查命令
  ctx.command('chartfox.status', '检查 ChartFox 服务状态')
    .action(async ({ session }) => {
      if (!chartFoxService) {
        return 'ChartFox 服务未配置'
      }
      
      try {
        await chartFoxService.searchAirports('TEST')
        return '✅ ChartFox 服务运行正常'
      } catch (error) {
        return `❌ ChartFox 服务异常: ${error.message}`
      }
    })
}